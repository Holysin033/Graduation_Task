# uni-app 音乐应用数据同步服务开发文档

## 项目概述

这是一个为uni-app音乐应用提供的数据同步服务，实现了本地数据与MySQL数据库的双向同步，支持多端数据一致性。服务采用Node.js + Express + MySQL架构，提供RESTful API接口。

## 技术栈

- 运行环境: Node.js (v14+)
- Web框架: Express.js
- 数据库: MySQL
- ORM/查询构建器: MySQL2
- API格式: RESTful JSON

## 开发环境搭建

### 前置要求

- MySQL 5.7+
- Node.js 14.0+
- npm 6.0+

### 安装步骤

1. **克隆项目并安装依赖**
   ```bash
   git clone <repository-url>
   cd backend
   npm install
   ```

2. **数据库配置**
   - 创建MySQL数据库: `music_app`
   - 运行初始化脚本: `node initdb.js`
   - 或手动导入SQL: `mysql -u user -p music_app < schema.sql`

3. **环境变量配置**
   创建`.env`文件:
   ```
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=yourpassword
   DB_NAME=music_app
   PORT=3002
   JWT_SECRET=your_jwt_secret_key
   ```

4. **启动服务**
   ```bash
   # 开发模式（带热重载）
   npm run dev
   
   # 生产模式
   npm start
   ```

服务将默认在3002端口启动。

## 项目结构详解

```
backend/
  ├── config/             # 配置文件目录
  │   ├── config.js       # 全局配置集中管理
  │   └── db.js           # 数据库连接及查询封装
  ├── controllers/        # 控制器目录
  │   ├── userController.js  # 用户相关业务逻辑
  │   └── syncController.js  # 同步相关业务逻辑
  ├── models/             # 数据模型目录
  │   ├── userModel.js    # 用户数据模型
  │   ├── favoriteModel.js # 收藏数据模型
  │   ├── historyModel.js # 历史记录模型
  │   ├── playlistModel.js # 歌单模型
  │   └── songModel.js    # 歌曲数据模型
  ├── routes/             # 路由目录
  │   ├── userRoutes.js   # 用户相关路由
  │   ├── syncRoutes.js   # 同步服务路由
  │   ├── favoritesRoutes.js # 收藏相关路由
  │   ├── historyRoutes.js   # 历史记录路由
  │   └── playlistRoutes.js  # 歌单相关路由
  ├── services/           # 服务层目录
  │   ├── userService.js  # 用户服务
  │   └── syncService.js  # 同步服务
  ├── middleware/         # 中间件目录
  │   ├── auth.js         # 认证中间件
  │   └── errorHandler.js # 错误处理中间件
  ├── utils/              # 工具函数目录
  │   ├── logger.js       # 日志工具
  │   └── helpers.js      # 通用辅助函数
  ├── app.js              # 应用主文件
  ├── server.js           # 服务器启动文件
  ├── initdb.js           # 数据库初始化脚本
  └── package.json        # 项目依赖配置
```

## 核心模块详解

### 1. 数据库连接模块 (config/db.js)

提供数据库连接池和查询封装:
```javascript
// 使用连接池提高性能
const pool = mysql.createPool({
  host: config.dbHost,
  user: config.dbUser,
  password: config.dbPassword,
  database: config.dbName,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 查询封装，支持参数化查询
async function query(sql, params = []) {
  try {
    const [rows] = await pool.execute(sql, params);
    return rows;
  } catch (error) {
    logger.error('数据库查询错误:', error);
    throw error;
  }
}
```

**扩展点**:
- 添加事务支持
- 实现查询缓存
- 添加数据库迁移功能

### 2. 同步服务模块 (services/syncService.js)

处理前端与数据库之间的数据同步:
```javascript
// 收藏同步实现示例
async function syncFavorites(userId, favorites) {
  try {
    // 获取数据库中的用户收藏
    const dbFavorites = await getFavorites(userId);
    
    // 合并本地和数据库收藏
    const mergedData = mergeFavorites(dbFavorites, favorites);
    
    // 更新数据库
    await updateFavorites(userId, mergedData);
    
    return mergedData;
  } catch (error) {
    logger.error(`同步收藏失败:${error.message}`);
    throw error;
  }
}
```

**扩展指南**:
- 实现增量同步以提高性能
- 添加冲突解决策略
- 实现更多数据类型的同步

### 3. 用户认证模块 (middleware/auth.js)

用户认证和授权中间件:
```javascript
// JWT认证中间件
function authenticate(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({
      code: 401,
      message: '未提供认证令牌'
    });
  }
  
  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({
      code: 401,
      message: '无效的认证令牌'
    });
  }
}
```

**扩展指南**:
- 实现基于角色的权限控制
- 添加令牌刷新机制
- 实现OAuth集成

## API接口规范

### 接口响应格式

所有API返回统一的JSON格式:
```javascript
{
  "code": 200,       // 状态码，200成功，其他表示错误
  "message": "...",  // 提示信息
  "data": {}         // 返回的数据，可能是对象或数组
}
```

### 错误处理

错误响应格式:
```javascript
{
  "code": 400,       // HTTP状态码
  "message": "...",  // 错误描述
  "error": "..."     // 详细错误信息(开发环境)
}
```

### API路由详解

#### 用户相关接口

| 方法 | 路由 | 描述 | 参数 | 权限 |
|------|------|------|------|------|
| POST | /api/users/login | 用户登录 | phone, password | 无 |
| POST | /api/users/register | 用户注册 | username, phone, password | 无 |
| GET | /api/users/:userId | 获取用户信息 | userId | 认证 |
| PUT | /api/users/:userId | 更新用户信息 | 用户字段 | 认证 |

#### 同步相关接口

| 方法 | 路由 | 描述 | 参数 | 权限 |
|------|------|------|------|------|
| GET | /api/sync/status/:userId | 获取同步状态 | userId | 认证 |
| GET | /api/sync/favorites/:userId | 获取收藏 | userId | 认证 |
| GET | /api/sync/play-history/:userId | 获取播放历史 | userId | 认证 |
| GET | /api/sync/playlists/:userId | 获取歌单 | userId | 认证 |
| POST | /api/sync/user-data | 同步用户数据 | userId, data对象 | 认证 |

#### 收藏相关接口

| 方法 | 路由 | 描述 | 参数 | 权限 |
|------|------|------|------|------|
| GET | /api/favorites/:userId | 获取收藏列表 | userId | 认证 |
| POST | /api/favorites/:userId | 添加收藏 | song对象 | 认证 |
| DELETE | /api/favorites/:userId/:songId | 删除收藏 | userId, songId | 认证 |

#### 历史记录接口

| 方法 | 路由 | 描述 | 参数 | 权限 |
|------|------|------|------|------|
| GET | /api/history/:userId | 获取播放历史 | userId | 认证 |
| POST | /api/history/:userId | 添加播放记录 | song对象 | 认证 |
| DELETE | /api/history/:userId | 清空播放历史 | userId | 认证 |

## 数据库设计

### 主要表结构

#### users表
```sql
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL,
  phone VARCHAR(20) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  avatar VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### favorites表
```sql
CREATE TABLE favorites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  song_id VARCHAR(100) NOT NULL,
  song_data JSON NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY user_song (user_id, song_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

#### play_history表
```sql
CREATE TABLE play_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  song_id VARCHAR(100) NOT NULL,
  song_data JSON NOT NULL,
  played_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_song (user_id, song_id)
);
```

## 安全最佳实践

1. **密码加密**: 使用bcrypt加密存储用户密码
2. **参数验证**: 使用express-validator验证请求参数
3. **SQL注入防护**: 使用参数化查询
4. **CORS配置**: 限制跨域请求
5. **速率限制**: 对敏感接口添加请求限制

## 性能优化策略

1. **数据库索引**: 为常用查询字段添加索引
2. **查询优化**: 减少不必要的JOIN操作
3. **连接池管理**: 合理设置连接池大小
4. **缓存策略**: 实现Redis缓存热点数据
5. **异步处理**: 将耗时操作放入消息队列

## 二次开发指南

### 添加新路由

1. 在routes目录创建新路由文件
2. 在app.js中注册路由
```javascript
// 在app.js中添加
const newRoutes = require('./routes/newRoutes');
app.use('/api/new-feature', newRoutes);
```

### 添加新数据模型

1. 在models目录创建新模型文件
2. 定义表结构和相关查询方法
3. 在相关服务中引用新模型

### 添加中间件

在middleware目录添加新中间件，如:
```javascript
// middleware/rateLimit.js
function rateLimit(options) {
  return (req, res, next) => {
    // 实现速率限制逻辑
    next();
  };
}
```

### 扩展同步功能

1. 在models中添加新数据类型的模型
2. 在syncService.js中添加对应的同步方法
3. 在syncRoutes.js中添加新的API端点

## 测试

```bash
# 运行单元测试
npm test

# 运行特定测试文件
npm test -- tests/user.test.js

# 测试覆盖率报告
npm run test:coverage
```

## 部署指南

### 本地开发环境
```bash
npm run dev
```

### 生产环境部署
```bash
# 安装PM2
npm install -g pm2

# 使用PM2启动应用
pm2 start server.js --name "music-sync"

# 查看日志
pm2 logs music-sync

# 监控应用
pm2 monit
```

### Docker部署
```bash
# 构建镜像
docker build -t music-sync-api .

# 运行容器
docker run -p 3002:3002 --name music-sync -e DB_HOST=db_host music-sync-api
```

## 常见问题解答

1. **数据同步冲突如何处理？**
   - 系统使用时间戳和版本号机制解决冲突
   - 可在syncService.js中自定义冲突解决策略

2. **如何处理大量数据同步？**
   - 实现分页加载
   - 使用增量同步减少传输数据量
   - 考虑使用WebSocket实现实时同步

3. **如何添加新的第三方认证？**
   - 在middleware/auth.js中添加新的认证策略
   - 在userRoutes.js中添加对应的登录路由

## 调试与监控

1. **日志系统**
   - 使用winston记录不同级别日志
   - 生产环境配置日志文件轮转

2. **性能监控**
   - 使用PM2监控应用状态
   - 集成APM工具监控性能指标

3. **API测试**
   - 使用Postman或Insomnia测试API
   - 保存API集合便于团队协作 